/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atvfinalbd;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;

/**
 *
 * @author isa_b
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AA__DataInserter {

    // Método para inserir dados na tabela
    public void inserirDados(String Categoria, String string, int par, int par1) {
        String sql = "INSERT INTO livros (Categoria, Nome, Ano, Quantidade) VALUES (?, ?, ?, ?)";
        
        // Usando try-with-resources para gerenciar a conexão e o PreparedStatement
        try (Connection connection = AA__ConexaoBD.conectar();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
             
            // Definindo os parâmetros
            pstmt.setString(1, Categoria); // Para Categoria
            String Nome = null;
            pstmt.setString(2, Nome);      // Para Nome
            int Ano = 0;
            pstmt.setInt(3, Ano);          // Para Ano
            int Quantidade = 0;
            pstmt.setInt(4, Quantidade);   // Para Quantidade

            // Executando a inserção
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("Linhas afetadas: " + rowsAffected);
            System.out.println("Dados inseridos com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao inserir dados: " + e.getMessage());
        }
    }

    // Método principal para testar
    public static void main(String[] args) {
        AA__DataInserter inserter = new AA__DataInserter();
        // Chame o método com dados de exemplo
        inserter.inserirDados("Ficção", "Cinderela", 1949, 5);
    }
}

    
    
    

