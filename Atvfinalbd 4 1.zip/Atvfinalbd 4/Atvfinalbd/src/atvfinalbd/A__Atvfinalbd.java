/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atvfinalbd; 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;






public class A__Atvfinalbd {



public class DataInserter {
    public void inserirDados(String texto) {
        String sql = "INSERT INTO livros (Categoria) VALUES (?)"; // Ajuste para sua tabela e coluna

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, texto); // Substitui o ? pelo texto inserido
            stmt.executeUpdate(); // Executa a inserção
            System.out.println("Dados inseridos com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Erro ao inserir dados: " + e.getMessage());
        }
    }
}
    
    
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/biblioteca"; 
        String user = "root"; // Usuário padrão do MySQL
        String password = ""; // Senha do MySQL (vazia por padrão no XAMPP)

        try {
            // Carregar o driver JDBC do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelecer conexão
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Conectado ao banco de dados!");

            // Exemplo: Inserir um dado na tabela
            String sqlInsert = "INSERT INTO clientes (Nome, CPF_cliente) VALUES (?,?)";
            PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert);
            pstmtInsert.setString(1, "Lucas");
            pstmtInsert.setInt(2, 111111);
            pstmtInsert.executeUpdate();
            System.out.println("Registro inserido com sucesso!");
            
            
            // Exemplo: Consultar dados da tabela
            String sqlSelect = "SELECT * FROM clientes";
            PreparedStatement pstmtSelect = conn.prepareStatement(sqlSelect);
            ResultSet rs = pstmtSelect.executeQuery();

            while (rs.next()) {
                int id_cliente = rs.getInt("id_cliente");
                String Nome = rs.getString("Nome");
                int CPF_cliente = rs.getInt("CPF_cliente"); 
                System.out.println("id_cliente: " + id_cliente + ", Nome: " + Nome + ", CPF_cliente: " + CPF_cliente);
            }

            // Fechar a conexão
            rs.close(); // Fechar ResultSet
            pstmtInsert.close(); // Fechar PreparedStatement
            pstmtSelect.close(); // Fechar PreparedStatement
            conn.close(); // Fechar conexão
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

public class ConexaoBD {
    private static final String URL = "jdbc:mysql://localhost:4306/biblioteca"; // Nome do seu banco
    private static final String USER = "root"; // Seu usuário do MySQL
    private static final String PASSWORD = ""; // Sua senha do MySQL

    public static Connection conectar() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
}



