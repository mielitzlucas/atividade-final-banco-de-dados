/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atvfinalbd;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author isa_b
 */
public class AA__ConexaoBD {
    
    
    private static final String URL = "jdbc:mysql://localhost:3306/biblioteca"; // Altere para o nome do seu banco
    private static final String USER = "root"; // Seu usuário do MySQL
    private static final String PASSWORD = ""; // Sua senha do MySQL

    public static Connection conectar() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace(); // Ajuda na depuração
            return null;
        }
    }
}

    
    
    
    